import time
import numpy as np
from typing import Dict, Any
from groq import Groq
import os
from .config import GROQ_API_KEY, SBERT_MODEL_PATH, DEFAULT_TOPK, ARTIFACTS_DIR
from .embeddings_utils import load_kb, load_faiss, get_model
from .intent_model import IntentPipeline
from .logger import log_query
import re

# Init Groq client (LLama 3 API)
client = Groq(api_key=GROQ_API_KEY)

# Lazy-loaded artifacts
_kb = None
_index = None
_intent = None
_model = None

BASE_DIR = os.path.dirname(__file__)  # folder tempat handler.py berada
ARTIFACTS_DIR = os.path.join(BASE_DIR, "artifacts")

def _ensure_loaded():
    global _kb, _index, _intent, _model
    if _kb is None:
        _kb = load_kb()
    if _index is None:
        _index = load_faiss()
    if _intent is None:
        _intent = IntentPipeline(path=os.path.join(ARTIFACTS_DIR, "intent_pipe.joblib"))
    if _model is None:
        _model = get_model(SBERT_MODEL_PATH)


async def call_llama_chat(system: str, user: str, model: str = "llama-3.1-8b-instant") -> str:
    """Call Groq Llama 3 ChatCompletion API"""
    resp = client.chat.completions.create(
        model=model,
        messages=[
            {"role": "system", "content": system},
            {"role": "user", "content": user},
        ],
        max_tokens=512,
        temperature=0.0,
    )
    return resp.choices[0].message.content


async def handle_query(user_id: str, text: str, topk: int = DEFAULT_TOPK, faissK: int = 30) -> Dict[str, Any]:
    _ensure_loaded()
    start = time.time()

    # ---------------------------
    # 1. Intent detection
    # ---------------------------
    intent: Dict[str, Any] = _intent.predict(text)
    if not isinstance(intent, dict):
        intent = {"mode": "default", "typePriority": None}
    else:
        intent.setdefault("mode", "default")
        intent.setdefault("typePriority", None)

    # ---------------------------
    # 2. Encode query
    # ---------------------------
    q_emb = _model.encode([text], normalize_embeddings=True).astype("float32")

    # ---------------------------
    # 3. FAISS search
    # ---------------------------
    D, I = _index.search(q_emb, faissK)
    ids = I[0].tolist()
    dists = D[0].tolist()

    df = _kb.iloc[ids].copy()
    df["distance"] = dists
    df["baseScore"] = -df["distance"]  # semakin dekat semakin besar

    # ---------------------------
    # 4. Type priority bonus
    # ---------------------------
    typePriority = intent.get("typePriority")
    if typePriority:
        priorityMap = {t: len(typePriority) - i for i, t in enumerate(typePriority)}
        df["typeBonus"] = df["type"].map(priorityMap).fillna(0)
    else:
        df["typeBonus"] = 0

    # ---------------------------
    # 5. Title keyword overlap bonus
    # ---------------------------
    qWords = set(re.findall(r"\w+", text.lower()))
    def titleBonus(title):
        titleWords = set(re.findall(r"\w+", str(title).lower()))
        return float(len(qWords & titleWords)) * 0.5
    df["titleBonus"] = df["title"].apply(titleBonus)

    # ---------------------------
    # 6. Duration bonus
    # ---------------------------
    if intent.get("mode") == "duration":
        maskCourse = df["type"] == "course"
        if maskCourse.any():
            df = df[maskCourse].copy()
        df["durationBonus"] = df["text"].str.contains("Estimated hours", case=False, na=False).astype(float) * 1.0
    else:
        df["durationBonus"] = 0.0

    # ---------------------------
    # 7. Final scoring
    # ---------------------------
    df["finalScore"] = df["baseScore"] + df["typeBonus"] + df["titleBonus"] + df["durationBonus"]

    # ---------------------------
    # 8. Sort top-K
    # ---------------------------
    df = df.sort_values("finalScore", ascending=False).head(topk)

    # ---------------------------
    # 9. Build context for LLM
    # ---------------------------
    docs = [f"[{r.get('id','')}] {r.get('title','')} - {str(r.get('text',''))[:800]}" for _, r in df.iterrows()]
    contexts = "\n\n".join(docs)

    system_prompt = (
        "You are a helpful assistant. Use ONLY the documents in the context. "
        "If the answer cannot be found there, clearly say so. Cite the doc ids."
    )
    user_prompt = f"User question: {text}\n\nContext documents:\n{contexts}\n\nAnswer concisely and list source ids."

    # ---------------------------
    # 10. Llama 3 response
    # ---------------------------
    llm_resp = await call_llama_chat(system_prompt, user_prompt)
    latency = int((time.time() - start) * 1000)

    # ---------------------------
    # 11. Build sources list
    # ---------------------------
    sources = [{"id": int(r.get("id", i)), "title": r.get("title"), "score": float(r.get("finalScore"))}
               for i, (_, r) in enumerate(df.iterrows())]

    result = {
        "response": llm_resp,
        "intent": intent,
        "sources": sources,
        "meta": {"latency_ms": latency},
    }

    # ---------------------------
    # 12. Logging
    # ---------------------------
    log_query(
        user_id=user_id,
        query=text,
        intent=intent,
        response=llm_resp,
        sources=sources,
        meta=result["meta"],
    )

    return result
