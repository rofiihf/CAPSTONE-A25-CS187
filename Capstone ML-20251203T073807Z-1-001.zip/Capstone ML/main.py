from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from app import init_db
from app.handler import handle_query
from app.scheduler import start_scheduler


engine = init_db()
start_scheduler()

app = FastAPI(title="Retrieval-Augmented Chat (Groq + SBERT + FAISS)")

class ChatReq(BaseModel):
    user_id: str
    text: str

@app.get("/health")
async def health():
    return {"status": "ok", "message": "API is running"}

@app.post('/chat')
async def chat(req: ChatReq):
    try:
        out = await handle_query(user_id=req.user_id, text=req.text)
        return out
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))