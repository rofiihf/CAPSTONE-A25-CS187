// backend/scripts/bootstrap_profiles.js
const { bootstrapAllProfiles } = require("../utils/user-profile");

bootstrapAllProfiles();
console.log("Bootstrapped profiles.");
