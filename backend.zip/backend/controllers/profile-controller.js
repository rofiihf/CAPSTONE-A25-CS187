// backend/controllers/profile-controller.js
const express = require("express");
const router = express.Router();
const { getProfile, updateProfile, ensureProfileExists } = require("../utils/user-profile");

router.get("/", (req, res) => {
  const userId = req.session?.userId;
  if (!userId) return res.status(401).json({ ok: false, message: "Not logged in" });
  const profile = getProfile(userId) || ensureProfileExists(userId);
  return res.json({ ok: true, profile });
});

router.post("/update", express.json(), (req, res) => {
  const userId = req.session?.userId;
  if (!userId) return res.status(401).json({ ok: false, message: "Not logged in" });
  const patch = req.body || {};
  const profile = updateProfile(userId, patch);
  return res.json({ ok: true, profile });
});

module.exports = router;
